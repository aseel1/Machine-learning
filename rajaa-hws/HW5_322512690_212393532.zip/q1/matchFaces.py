# Rajaa haj, 322512690
# Aseel shaheen, 212393532

# Please replace the above comments with your names and ID numbers in the same format.

import cv2
import numpy as np
import matplotlib.pyplot as plt
from numpy.fft import fft2, ifft2, fftshift, ifftshift

from scipy.ndimage import maximum_filter

import warnings
warnings.filterwarnings("ignore")

def scale_down(image, resize_ratio):

    #apply gaussian filter to the image 
    image=cv2.GaussianBlur(image,(5,5),0)

    # get the shifted fourier transform  
    fft_shifted=fftshift(fft2(image))
    
    height, width=fft_shifted.shape

    #get the new demension 
    new_height=int(height*resize_ratio) 
    new_width= int(width*resize_ratio)

    start_height=(height-new_height)//2
    start_width=(width-new_width)//2

    #Crop the frequency domain image to the new dimensions
    cropped_f_image=fft_shifted[start_height:start_height+new_height,
                                start_width:start_width+new_width]


    # get the inverse fft
    scaled_down_image=np.abs(ifft2(ifftshift(cropped_f_image)))

    return scaled_down_image



def scale_up(image, resize_ratio):
    
    # get the shifted fourier transform  
    fft_shifted=fftshift(fft2(image))

    height, width=fft_shifted.shape

    #get the new demension 
    new_height=int(height*resize_ratio) 
    new_width= int(width*resize_ratio)

    #get new zero matrix with the new diemnsions 
    padded_transform=np.zeros((new_height,new_width),dtype=complex)

    #center the freqency domian in the new zero padded matrix 
    start_height=(new_height-height)//2
    start_width=(new_width-width)//2

    #update the center of the padded matrix with the orignal fft 
    padded_transform[start_height:start_height+height,
                   start_width:start_width+width]=fft_shifted
    

    # get the inverse fft
    scaled_up_image=np.abs(ifft2(ifftshift(padded_transform)))

    scaled_up_image*= (resize_ratio**2)

    scaled_up_image=np.clip(scaled_up_image,0,255).astype(np.uint8)

    return scaled_up_image



def ncc_2d(image, pattern):

    windows_shape=pattern.shape

    # intiialize the ncc image with zeros 
    ncc_image=np.zeros(image.shape)
    
    mean_pattern=np.mean(pattern)
	
    #normilaze the pattern 
    norm_pattern =pattern-mean_pattern

    #get the the possible windows 
    windows=np.lib.stride_tricks.sliding_window_view(image,windows_shape) 

    # calculate the ncc value for all the windows in the image  
    for i in range (windows.shape[0]):
          for j in range(windows.shape[1]):
                
                curr_window=windows[i,j]
                curr_mean=np.mean(curr_window)
                
                norm_window=curr_window- curr_mean
                
                numerator=np.sum(norm_window*norm_pattern)

                
                denominator=np.sqrt(np.sum(norm_window**2)*np.sum(norm_pattern**2))

                # get the ncc value , in case the denominator equal to zero update the ncc value to be zero 
                ncc_value= numerator/denominator if denominator !=0 else 0 
            
                ncc_image[i,j]= ncc_value
                
    return ncc_image
                      

def display(image, pattern):
	
	plt.subplot(2, 3, 1)
	plt.title('Image')
	plt.imshow(image, cmap='gray')
		
	plt.subplot(2, 3, 3)
	plt.title('Pattern')
	plt.imshow(pattern, cmap='gray', aspect='equal')
	
	ncc = ncc_2d(image, pattern)
	
	plt.subplot(2, 3, 5)
	plt.title('Normalized Cross-Correlation Heatmap')
	plt.imshow(ncc ** 2, cmap='coolwarm', vmin=0, vmax=1, aspect='auto') 
	
	cbar = plt.colorbar()
	cbar.set_label('NCC Values')
	
	plt.show()
 
 


def draw_matches(image, matches, pattern_size):
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    for point in matches:
        y, x = point
        top_left = (int(x - pattern_size[1]/2), int(y - pattern_size[0]/2))
        bottom_right = (int(x + pattern_size[1]/2), int(y + pattern_size[0]/2))
        cv2.rectangle(image, top_left, bottom_right, (255, 0, 0), 1)
	
    plt.imshow(image, cmap='gray')
    plt.show()
	
    cv2.imwrite(f"{CURR_IMAGE}_result.jpg", image)



CURR_IMAGE = "thecrew"

image = cv2.imread(f'q1/{CURR_IMAGE}.jpg')
image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

pattern = cv2.imread('q1/template.jpg')
pattern = cv2.cvtColor(pattern, cv2.COLOR_BGR2GRAY)



# ############# Students #############

# resize_ratio_down = 0.69# scale down ratio
# resize_ratio_up = 1.28 # scale up ratio

# image_scaled =  scale_up(image,resize_ratio_up)
# patten_scaled =  scale_down(pattern, resize_ratio_down)

# display(image_scaled, patten_scaled)

# ncc = ncc_2d(image_scaled, patten_scaled)
# ncc[ncc!= maximum_filter(ncc, size=(40,20))]=0
# threshold = 0.53

# real_matches =np.argwhere(ncc >= threshold)

# ######### DONT CHANGE THE NEXT TWO LINES #########
# real_matches[:,0] += patten_scaled.shape[0] // 2			# if pattern was not scaled, replace this with "pattern"
# real_matches[:,1] += patten_scaled.shape[1] // 2			# if pattern was not scaled, replace this with "pattern"

# # If you chose to scale the original image, make sure to scale back the matches in the inverse resize ratio.
# real_matches[:,0]=(real_matches[:,0]*(1/resize_ratio_up)).astype(int)
# real_matches[:,1]=(real_matches[:,1]*(1/resize_ratio_up)).astype(int)

# draw_matches(image, real_matches, patten_scaled.shape)	# if pattern was not scaled, replace this with "pattern"


############# Crew #############

resize_ratio_down1=0.4
resize_ratio_up1=1.65

image_scaled = scale_up(image,resize_ratio_up1)
patten_scaled = scale_down(pattern, resize_ratio_down1)

# patten_scaled = pattern
# image_scaled=image

display(image_scaled, patten_scaled)

ncc = ncc_2d(image_scaled, patten_scaled)
ncc[ncc!= maximum_filter(ncc, size=(40,20))]=0
threshold1 = 0.442
real_matches = np.argwhere(ncc >= threshold1)
#print(np.max(ncc))

######### DONT CHANGE THE NEXT TWO LINES #########
real_matches[:,0] += patten_scaled.shape[0] // 2			# if pattern was not scaled, replace this with "pattern"
real_matches[:,1] += patten_scaled.shape[1] // 2			# if pattern was not scaled, replace this with "pattern"

# If you chose to scale the original image, make sure to scale back the matches in the inverse resize ratio.
real_matches[:,0]=(real_matches[:,0]*(1/resize_ratio_up1)).astype(int)
real_matches[:,1]=(real_matches[:,1]*(1/resize_ratio_up1)).astype(int)

draw_matches(image, real_matches, patten_scaled.shape)	# if pattern was not scaled, replace this with "pattern"
