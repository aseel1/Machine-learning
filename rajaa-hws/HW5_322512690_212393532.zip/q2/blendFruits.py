# Rajaa haj, 322512690
# Aseel shaheen, 212393532

#Please replace the above comments with your names and ID numbers in the same format.

import cv2
import numpy as np
import matplotlib.pyplot as plt



def resize_image(image,resize_ratio):
     
     height,width=image.shape
     new_height=int(height*resize_ratio)
     new_width=int(width*resize_ratio)
     resized_image=cv2.resize(image,(new_height,new_width),interpolation=cv2.INTER_LINEAR)

     return resized_image

def get_gaussian_pyramid(image, levels,resize_ratio=0.5):

	image = np.float32(image)/255.0
	gaussian_pyr=[image]
     
	for _ in range(1,levels):
          
		#apply gaussian blur
		curr_img=cv2.GaussianBlur(gaussian_pyr[-1],(5,5),0)
        #down sample the image half of its size 
		down_sample=resize_image(curr_img,resize_ratio)
		gaussian_pyr.append(down_sample)

	return gaussian_pyr



def get_laplacian_pyramid(image, levels, resize_ratio=0.5):

    # get gaussian pyramid
    gaussian_pyr=get_gaussian_pyramid(image,levels,resize_ratio)

    # get laplacian pyramid 
    laplacianPyr=[] 

    for i in range(levels-1):

        curr_img=gaussian_pyr[i]
          
        next_img=gaussian_pyr[i+1]
      
        #up sample the next image twice its size 
        up_sample=resize_image(next_img,1/resize_ratio)

        if up_sample.shape!=curr_img.shape:
            up_sample=cv2.resize(up_sample,(curr_img.shape[1],curr_img.shape[0]))

		#substract the next_img from the current image to get curr laplacian layer 
        laplacian=cv2.subtract(curr_img,up_sample)
       
        laplacianPyr.append(laplacian)
            
    #add the last layer 
    laplacianPyr.append(gaussian_pyr[-1])
    return laplacianPyr
    
    

def restore_from_pyramid(pyramidList, resize_ratio=2):
	# Your code goes here

    prev_level=pyramidList[-1]
	
    for level in reversed(pyramidList[:-1]):
        
        #up sample the prev layer 
        next=resize_image(prev_level,resize_ratio)
        #check the shape of the upsampled image 
        if next.shape != level.shape:
            next=cv2.resize(next,(level.shape[1],level.shape[0]))

        prev_level=cv2.add(next,level)
        
                   
    result=np.clip(prev_level * 255, 0, 255).astype('uint8')
	
    return  result 



def validate_operation(img):
    pyr = get_laplacian_pyramid(img,5)
    img_restored = restore_from_pyramid(pyr)

    plt.title(f"MSE is {np.mean((img_restored - img) ** 2)}")
    plt.imshow(img_restored, cmap='gray')

    plt.show()


def blend_pyramids(first_pyr,secound_pyr,levels):
	# Your code goes here
    blended_pyr=[]

    for curr_level in range(levels):
		
	    #get the image in the curr level from both pyramids 
        first_img=first_pyr[curr_level]
        secound_img=secound_pyr[curr_level]

        Width=secound_img.shape[0]
        mask=np.zeros_like(secound_img)

        index=levels-curr_level

        start_index = int(Width * 0.5 - index)
        end_index = int(Width * 0.5 + index) + 1

        mask[:, :start_index]=1

        for j in range (start_index,end_index):
            
            mask[:,j]=0.9-0.9*(j-start_index)/(2*(index)+1)

        blended_img=secound_img*mask +first_img*(1-mask)
        blended_pyr.append(blended_img)
	
    return blended_pyr




apple = cv2.imread('apple.jpg')
apple = cv2.cvtColor(apple, cv2.COLOR_BGR2GRAY)

orange = cv2.imread('orange.jpg')
orange = cv2.cvtColor(orange, cv2.COLOR_BGR2GRAY)

validate_operation(apple)
validate_operation(orange)

levels_num=6

pyr_apple = get_laplacian_pyramid(apple,levels_num)
pyr_orange = get_laplacian_pyramid(orange,levels_num)


pyr_result = []

pyr_result=blend_pyramids(pyr_apple,pyr_orange,levels_num)

# Your code goes here

final = restore_from_pyramid(pyr_result)
plt.imshow(final, cmap='gray')
plt.show()

cv2.imwrite("result.jpg", final)

